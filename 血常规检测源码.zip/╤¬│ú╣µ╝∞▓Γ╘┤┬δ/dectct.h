#ifndef DECTCT_H
#define DECTCT_H

#include <QPushButton>
#include <QWidget>
#include <QMessageBox>

#include "war.h"

namespace Ui {
class dectct;
}

class dectct : public QWidget
{
    Q_OBJECT


signals:
    void back();

public:
    explicit dectct(QWidget *parent = nullptr);
    ~dectct();
    War *warpage = nullptr;

private slots:

    void on_Start_clicked();

private:
    Ui::dectct *ui;
};

#endif // DECTCT_H
