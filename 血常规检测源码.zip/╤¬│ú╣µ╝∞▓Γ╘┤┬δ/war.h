#ifndef WAR_H
#define WAR_H

#include <QTranslator>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QWidget>
#include <QTableWidget>
#include <QCoreApplication>
#include <QSqlError>
#include <QDebug>
#include <QList>
#include <QMap>
#include <QSqlRecord>
#include "global.h"
#include "mydata.h"
#include "waritem.h"

namespace Ui {
class War;
}

class War : public QWidget
{
    Q_OBJECT

public:
    explicit War(QWidget *parent = nullptr);
    ~War();
    static warItem waritem;

signals:
    void back();


private slots:
    void on_gtprint_clicked();
    QMap<int,mydata> queryAllDataFromTable(const QString& tableName);

private:
    Ui::War *ui;
    void setupTable(int n);
};


#endif // WAR_H
