#ifndef MYUSER_H
#define MYUSER_H

#include <QWidget>
class myUser
{
public:
    myUser();

    const QString &getName() const {
        return name;
    }

    void setName(const QString &name) {
        myUser::name = name;
    }

    const QString &getTel() const {
        return tel;
    }

    void setTel(const QString &tel) {
        myUser::tel = tel;
    }

    const QString &getSex() const {
        return sex;
    }

    void setSex(const QString &sex) {
        myUser::sex = sex;
    }

    const QString &getAge() const {
        return age;
    }

    void setAge(const QString &age) {
        myUser::age = age;
    }


private:
    QString name;
    QString tel;
    QString sex;
    QString age;
};

#endif // MYUSER_H
