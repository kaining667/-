#ifndef MALEPAGE_H
#define MALEPAGE_H

#include <QPushButton>
#include <QWidget>
#include <QMessageBox>

#include "war.h"
#include "global.h"

namespace Ui {
class malePage;
}

class malePage : public QWidget
{
    Q_OBJECT

public:
    explicit malePage(QWidget *parent = nullptr);
    ~malePage();
    War *warpage = nullptr;

signals:
    void back();

private slots:
    void on_pushButton_3_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::malePage *ui;
};

#endif // MALEPAGE_H
