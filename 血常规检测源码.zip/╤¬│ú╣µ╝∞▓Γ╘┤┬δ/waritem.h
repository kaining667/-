#ifndef WARITEM_H
#define WARITEM_H

#include <vector>
#include <string>

class warItem
{
public:
    warItem();

    warItem(std::vector<std::pair<int,double>> mywar){
        this -> myWar = mywar;
        this -> size = mywar.size();
    }

    int getSize() const {
        return size;
    }

    void setSize(int size) {
        warItem::size = size;
    }

    const std::vector<std::pair<int,double>> &getMyWar() const {
        return myWar;
    }

    void setMyWar(const std::vector<std::pair<int,double>> &myWar) {
        warItem::myWar = myWar;
    }

private:
    int size;
    std::vector<std::pair<int,double>> myWar;
};

#endif // WARITEM_H
