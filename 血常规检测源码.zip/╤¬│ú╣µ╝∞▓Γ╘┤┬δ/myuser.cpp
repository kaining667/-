#include "myuser.h"

myUser::myUser() {

}
