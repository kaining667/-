#include "malepage.h"
#include "ui_malepage.h"
#include "war.h"
#include "waritem.h"


malePage::malePage(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::malePage)
{
    ui->setupUi(this);

    connect(ui -> pushButton, &QPushButton::clicked,[=](){
        emit this -> back();
    });

    this -> warpage = new War;
}

malePage::~malePage()
{
    delete ui;
}

void malePage::on_pushButton_3_clicked()
{

}


void malePage::on_pushButton_2_clicked()
{
    QString war = "";
    std::vector<std::vector<std::string>> mywar;
    double l1 = (ui -> l1 -> text()).toDouble();
    if(l1>5.8)war.push_back("脱水、真性红细胞增多症、高原缺氧、肺心病\n");
    else if(l1<4.3)war.push_back("贫血（缺铁性、溶血性、再生障碍性）、失血、白血病、慢性肾\n");
    if(l1>5.8){
        std::vector<std::string> mywar1;
        mywar1.push_back("红细胞计数(RBC)");
        mywar1.push_back("4.3-5.8×10^12L");
        mywar1.push_back("偏高");
        mywar1.push_back("脱水、真性红细胞增多症、高原缺氧、肺心病");
        mywar.push_back(mywar1);
    }
    else if(l1<4.3){
        std::vector<std::string> mywar1;
        mywar1.push_back("红细胞计数(RBC)");
        mywar1.push_back("4.3-5.8×10^12L");
        mywar1.push_back("偏低");
        mywar1.push_back("贫血（缺铁性、溶血性、再生障碍性）、失血、白血病、慢性肾");
        mywar.push_back(mywar1);
    }

    double l2 = (ui -> l2 -> text()).toDouble();
    if(l2>160)war.push_back("同RBC偏高（血液浓缩或红细胞增多症）\n");
    else if(l2<120)war.push_back("同RBC偏低（贫血、失血、骨髓抑制）\n");
    if(l2>160){
        std::vector<std::string> mywar1;
        mywar1.push_back("血红蛋白(Hb)");
        mywar1.push_back("120-160g/L ");
        mywar1.push_back("偏高");
        mywar1.push_back("同RBC偏高（血液浓缩或红细胞增多症）");
        mywar.push_back(mywar1);
    }
    else if(l2<120){
        std::vector<std::string> mywar1;
        mywar1.push_back("血红蛋白(Hb)");
        mywar1.push_back("120-160g/L ");
        mywar1.push_back("偏低");
        mywar1.push_back("同RBC偏低（贫血、失血、骨髓抑制）");
        mywar.push_back(mywar1);
    }

    double l3 = (ui -> l3-> text()).toDouble();
    if(l3>50)war.push_back("脱水、红细胞增多症 \n");
    else if(l3<40)war.push_back("贫血、失血、妊娠、过度输液\n");
    if(l3>50){
        std::vector<std::string> mywar1;
        mywar1.push_back("血细胞比容(Hct)");
        mywar1.push_back("40%-50% ");
        mywar1.push_back("偏高");
        mywar1.push_back("脱水、红细胞增多症");
        mywar.push_back(mywar1);
    }
    else if(l3<40){
        std::vector<std::string> mywar1;
        mywar1.push_back("血细胞比容(Hct)");
        mywar1.push_back("40%-50% ");
        mywar1.push_back("偏低");
        mywar1.push_back("贫血、失血、妊娠、过度输液");
        mywar.push_back(mywar1);
    }

    double l4 = (ui -> l4-> text()).toDouble();
    if(l4>100)war.push_back("巨幼细胞贫血（维生素B12/叶酸缺乏）、肝病、甲状腺功能减退 \n");
    else if(l4<80)war.push_back("缺铁性贫血、地中海贫血、慢性病性贫血\n");
    if(l4>100){
        std::vector<std::string> mywar1;
        mywar1.push_back("平均血细胞体积(MCV)");
        mywar1.push_back("80-100 fL ");
        mywar1.push_back("偏高");
        mywar1.push_back("巨幼细胞贫血（维生素B12/叶酸缺乏）、肝病、甲状腺功能减退");
        mywar.push_back(mywar1);
    }
    else if(l4<80){
        std::vector<std::string> mywar1;
        mywar1.push_back("平均血细胞体积(MCV)");
        mywar1.push_back("80-100 fL ");
        mywar1.push_back("偏低");
        mywar1.push_back("缺铁性贫血、地中海贫血、慢性病性贫血");
        mywar.push_back(mywar1);
    }

    double l5 = (ui -> l5-> text()).toDouble();
    if(l5>34)war.push_back("遗传性球形红细胞增多症、溶血性贫血 \n");
    else if(l5<27)war.push_back("缺铁性贫血、地中海贫血\n");
    if(l5>34){
        std::vector<std::string> mywar1;
        mywar1.push_back("平均血红蛋白含量(MCH)");
        mywar1.push_back("27-34 pg");
        mywar1.push_back("偏高");
        mywar1.push_back("遗传性球形红细胞增多症、溶血性贫血");
        mywar.push_back(mywar1);
    }
    else if(l5<27){
        std::vector<std::string> mywar1;
        mywar1.push_back("平均血红蛋白含量(MCH)");
        mywar1.push_back("27-34 pg ");
        mywar1.push_back("偏低");
        mywar1.push_back("缺铁性贫血、地中海贫血");
        mywar.push_back(mywar1);
    }


    double l6 = (ui -> l5-> text()).toDouble();
    if(l6>360)war.push_back("遗传性球形红细胞增多症、溶血性贫血 \n");
    else if(l6<2320)war.push_back("缺铁性贫血、地中海贫血\n");
    if(l6>360){
        std::vector<std::string> mywar1;
        mywar1.push_back("平均血红蛋白浓度(MCHC)");
        mywar1.push_back("320-360g/L");
        mywar1.push_back("偏高");
        mywar1.push_back("遗传性球形红细胞增多症、溶血性贫血");
        mywar.push_back(mywar1);
    }
    else if(l6<320){
        std::vector<std::string> mywar1;
        mywar1.push_back("平均血红蛋白浓度(MCHC)");
        mywar1.push_back("320-360g/L ");
        mywar1.push_back("偏低");
        mywar1.push_back("缺铁性贫血、地中海贫血");
        mywar.push_back(mywar1);
    }


    double l7 = (ui -> l7-> text()).toDouble();
    if(l7>14.5)war.push_back("缺铁性贫血、混合营养性贫血 \n");
    else if(l7<11)war.push_back("无显著临床意义 \n");
    if(l7>14.5){
        std::vector<std::string> mywar1;
        mywar1.push_back("红细胞分布密度(RDW)");
        mywar1.push_back("11%-14.5%");
        mywar1.push_back("偏高");
        mywar1.push_back("缺铁性贫血、混合营养性贫血");
        mywar.push_back(mywar1);
    }
    else if(l7<11){
        std::vector<std::string> mywar1;
        mywar1.push_back("红细胞分布密度(RDW)");
        mywar1.push_back("11%-14.5%");
        mywar1.push_back("偏低");
        mywar1.push_back("无显著临床意义 ");
        mywar.push_back(mywar1);
    }


    double l8 = (ui -> l8-> text()).toDouble();
    if(l8>10)war.push_back("细菌感染、炎症、白血病、应激反应（如外伤、手术） \n");
    else if(l8<4)war.push_back("病毒感染（流感、肝炎）、再生障碍性贫血、药物副作用（化疗）、放射线损伤、脾功能亢进 \n");
    if(l8>10){
        std::vector<std::string> mywar1;
        mywar1.push_back("白细胞总数(WBC)");
        mywar1.push_back("成人：4-10×10⁹/L");
        mywar1.push_back("偏高");
        mywar1.push_back("细菌感染、炎症、白血病、应激反应（如外伤、手术）");
        mywar.push_back(mywar1);
    }
    else if(l8<4){
        std::vector<std::string> mywar1;
        mywar1.push_back("白细胞总数(WBC)");
        mywar1.push_back("成人：4-10×10⁹/L");
        mywar1.push_back("偏低");
        mywar1.push_back("病毒感染（流感、肝炎）、再生障碍性贫血、药物副作用（化疗）、放射线损伤、脾功能亢进 ");
        mywar.push_back(mywar1);
    }


    double l9 = (ui -> l9-> text()).toDouble();
    if(l9>75)war.push_back("细菌感染、炎症、烧伤、急性出血 \n");
    else if(l9<40)war.push_back("严重感染（脓毒症）、药物（化疗、抗生素）、自身免疫病、骨髓抑制 \n");
    if(l9>75){
        std::vector<std::string> mywar1;
        mywar1.push_back("中性线粒体百分比(NEUT%)");
        mywar1.push_back("40%-75%");
        mywar1.push_back("偏高");
        mywar1.push_back("细菌感染、炎症、烧伤、急性出血");
        mywar.push_back(mywar1);
    }
    else if(l9<40){
        std::vector<std::string> mywar1;
        mywar1.push_back("中性线粒体百分比(NEUT%)");
        mywar1.push_back("40%-75%");
        mywar1.push_back("偏低");
        mywar1.push_back("严重感染（脓毒症）、药物（化疗、抗生素）、自身免疫病、骨髓抑制 ");
        mywar.push_back(mywar1);
    }


    double l10 = (ui -> l10-> text()).toDouble();
    if(l10>40)war.push_back("病毒感染（EB病毒、肝炎）、结核、淋巴细胞白血病 \n");
    else if(l10<20)war.push_back("免疫缺陷（HIV）、药物（激素）、放疗后、严重细菌感染 \n");
    if(l10>40){
        std::vector<std::string> mywar1;
        mywar1.push_back("淋巴细胞百分比(LYMPH%)");
        mywar1.push_back("20%-40% ");
        mywar1.push_back("偏高");
        mywar1.push_back("病毒感染（EB病毒、肝炎）、结核、淋巴细胞白血病");
        mywar.push_back(mywar1);
    }
    else if(l10<20){
        std::vector<std::string> mywar1;
        mywar1.push_back("淋巴细胞百分比(LYMPH%)");
        mywar1.push_back("20%-40%  ");
        mywar1.push_back("偏低");
        mywar1.push_back("免疫缺陷（HIV）、药物（激素）、放疗后、严重细菌感染 ");
        mywar.push_back(mywar1);
    }


    double l11 = (ui -> l11-> text()).toDouble();
    if(l11>10)war.push_back("慢性感染（结核）、自身免疫病（狼疮）、血液病（白血病) \n");
    else if(l11<3)war.push_back("一般无特殊意义，严重骨髓抑制时减少 \n");
    if(l11>10){
        std::vector<std::string> mywar1;
        mywar1.push_back("单核细胞百分比(MONO%)");
        mywar1.push_back("3%-10% ");
        mywar1.push_back("偏高");
        mywar1.push_back("慢性感染（结核）、自身免疫病（狼疮）、血液病（白血病)");
        mywar.push_back(mywar1);
    }
    else if(l11<3){
        std::vector<std::string> mywar1;
        mywar1.push_back("单核细胞百分比(MONO%)");
        mywar1.push_back("3%-10%  ");
        mywar1.push_back("偏低");
        mywar1.push_back("一般无特殊意义，严重骨髓抑制时减少 ");
        mywar.push_back(mywar1);
    }


    double l12 = (ui -> l12-> text()).toDouble();
    if(l12>5)war.push_back("过敏、寄生虫感染、皮肤病（湿疹）、血液病（嗜酸性粒细胞增多症） \n");
    else if(l12<0.5)war.push_back("急性感染早期、激素治疗 \n");
    if(l12>5){
        std::vector<std::string> mywar1;
        mywar1.push_back("嗜酸性线粒体百分比(EO%)");
        mywar1.push_back("0.5%-5% ");
        mywar1.push_back("偏高");
        mywar1.push_back("过敏、寄生虫感染、皮肤病（湿疹）、血液病（嗜酸性粒细胞增多症）");
        mywar.push_back(mywar1);
    }
    else if(l12<0.5){
        std::vector<std::string> mywar1;
        mywar1.push_back("嗜酸性线粒体百分比(EO%)");
        mywar1.push_back("0.5%-5%  ");
        mywar1.push_back("偏低");
        mywar1.push_back("急性感染早期、激素治疗 ");
        mywar.push_back(mywar1);
    }

    double l13 = (ui -> l13-> text()).toDouble();
    if(l13>1)war.push_back("髓增殖性疾病（慢性粒细胞白血病）、过敏反应 \n");
    else if(l13<0)war.push_back("一般无特殊意义 \n");
    if(l13>1){
        std::vector<std::string> mywar1;
        mywar1.push_back("嗜碱性线粒体百分比(BASO%)");
        mywar1.push_back("0%-1%  ");
        mywar1.push_back("偏高");
        mywar1.push_back("髓增殖性疾病（慢性粒细胞白血病）、过敏反应");
        mywar.push_back(mywar1);
    }
    else if(l13<0){
        std::vector<std::string> mywar1;
        mywar1.push_back("嗜碱性线粒体百分比(BASO%)");
        mywar1.push_back("0%-1%  ");
        mywar1.push_back("偏低");
        mywar1.push_back("一般无特殊意义 ");
        mywar.push_back(mywar1);
    }

    double l14 = (ui -> l14-> text()).toDouble();
    if(l14>300)war.push_back("炎症、缺铁性贫血、骨髓增殖性疾病（原发性血小板增多症）、脾切除术后 \n");
    else if(l14<100)war.push_back("血小板减少症（免疫性、药物性）、再生障碍性贫血、DIC、脾功能亢进 \n");
    if(l14>300){
        std::vector<std::string> mywar1;
        mywar1.push_back("血小板计数(PLT)");
        mywar1.push_back("100-300×10⁹/L  ");
        mywar1.push_back("偏高");
        mywar1.push_back("炎症、缺铁性贫血、骨髓增殖性疾病（原发性血小板增多症）、脾切除术后");
        mywar.push_back(mywar1);
    }
    else if(l14<100){
        std::vector<std::string> mywar1;
        mywar1.push_back("血小板计数(PLT)");
        mywar1.push_back("100-300×10⁹/L ");
        mywar1.push_back("偏低");
        mywar1.push_back("血小板减少症（免疫性、药物性）、再生障碍性贫血、DIC、脾功能亢进 ");
        mywar.push_back(mywar1);
    }

    double l15 = (ui -> l15-> text()).toDouble();
    if(l15>12)war.push_back("骨髓活跃（出血后恢复期）、免疫性血小板减少症 \n");
    else if(l15<7)war.push_back("骨髓抑制（化疗后）、再生障碍性贫血 \n");
    if(l15>12){
        std::vector<std::string> mywar1;
        mywar1.push_back("平均血小板体积(MPV)");
        mywar1.push_back(" 7-12 fL ");
        mywar1.push_back("偏高");
        mywar1.push_back("骨髓活跃（出血后恢复期）、免疫性血小板减少症");
        mywar.push_back(mywar1);
    }
    else if(l15<7){
        std::vector<std::string> mywar1;
        mywar1.push_back("平均血小板体积(MPV)");
        mywar1.push_back(" 7-12 fL ");
        mywar1.push_back("偏低");
        mywar1.push_back("骨髓抑制（化疗后）、再生障碍性贫血 ");
        mywar.push_back(mywar1);
    }


    double l16 = (ui -> l16-> text()).toDouble();
    if(l16>17)war.push_back("血小板活化（炎症、血栓）、骨髓异常造血 \n");
    else if(l16<15)war.push_back("一般无显著意义 \n");
    if(l16>12){
        std::vector<std::string> mywar1;
        mywar1.push_back("血小板分布宽度(PDW)");
        mywar1.push_back(" 15%-17% ");
        mywar1.push_back("偏高");
        mywar1.push_back("血小板活化（炎症、血栓）、骨髓异常造血");
        mywar.push_back(mywar1);
    }
    else if(l16<17){
        std::vector<std::string> mywar1;
        mywar1.push_back("血小板分布宽度(PDW)");
        mywar1.push_back(" 15%-17% ");
        mywar1.push_back("偏低");
        mywar1.push_back("一般无显著意义 ");
        mywar.push_back(mywar1);
    }

    double l17 = (ui -> l17-> text()).toDouble();
    if(l17>1.5)war.push_back("血性贫血、失血后恢复期、骨髓增生  \n");
    else if(l17<0.5)war.push_back("再生障碍性贫血、骨髓抑制（化疗/放疗）、缺铁性贫血未纠正 \n");
    if(l17>1.5){
        std::vector<std::string> mywar1;
        mywar1.push_back("网织红细胞计数(Ret%)");
        mywar1.push_back(" 成人：0.5%-1.5%");
        mywar1.push_back("偏高");
        mywar1.push_back("血性贫血、失血后恢复期、骨髓增生 ");
        mywar.push_back(mywar1);
    }
    else if(l17<0.5){
        std::vector<std::string> mywar1;
        mywar1.push_back("网织红细胞计数(Ret%)");
        mywar1.push_back(" 成人：0.5%-1.5%");
        mywar1.push_back("偏低");
        mywar1.push_back("再生障碍性贫血、骨髓抑制（化疗/放疗）、缺铁性贫血未纠正 ");
        mywar.push_back(mywar1);
    }


    this -> warpage = new War;
    warpage -> show();
}

