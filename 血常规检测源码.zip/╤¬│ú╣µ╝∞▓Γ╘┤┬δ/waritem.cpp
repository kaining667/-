#include "waritem.h"

warItem::warItem() {}
