#include "dectct.h"
#include "ui_dectct.h"
#include "war.h"

dectct::dectct(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::dectct)
{
    ui->setupUi(this);

    // 创建垂直布局
    QVBoxLayout *layout = new QVBoxLayout(this);
    // 将ui添加到布局中
    layout->addWidget(ui->widget);
    // 设置布局到窗口
    this->setLayout(layout);

    connect(ui -> lastPage, &QPushButton::clicked,[=](){
        emit this -> back();
    });

    //warpage
    this -> warpage = new War;
}

dectct::~dectct()
{
    delete ui;
}


void dectct::on_Start_clicked()
{
    std::vector<std::pair<int,double>> mywar;
    QString l1 = (ui -> l1 -> text());
    if(!l1.isEmpty())mywar.push_back({1,l1.toDouble()});

    QString l2 = (ui -> l2 -> text());
    if(!l2.isEmpty())mywar.push_back({2,l2.toDouble()});

    QString l3 = (ui -> l3 -> text());
    if(!l3.isEmpty())mywar.push_back({3,l3.toDouble()});

    QString l4 = (ui -> l4 -> text());
    if(!l4.isEmpty())mywar.push_back({4,l4.toDouble()});

    QString l5 = (ui -> l5 -> text());
    if(!l5.isEmpty())mywar.push_back({5,l5.toDouble()});

    QString l6 = (ui -> l6 -> text());
    if(!l6.isEmpty())mywar.push_back({6,l6.toDouble()});

    QString l7 = (ui -> l7 -> text());
    if(!l7.isEmpty())mywar.push_back({7,l7.toDouble()});

    QString l8 = (ui -> l8 -> text());
    if(!l8.isEmpty())mywar.push_back({8,l8.toDouble()});

    myitem.setMyWar(mywar);
    this -> warpage = new War;
    warpage -> show();
}

