#include "mydata.h"

mydata::mydata() {}
