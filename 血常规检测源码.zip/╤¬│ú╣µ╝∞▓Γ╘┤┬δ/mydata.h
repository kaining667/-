#ifndef MYDATA_H
#define MYDATA_H

#include <QString>

class mydata
{
public:
    mydata();

    const QString &getHi() const {
        return hi;
    }

    void setHi(const QString &hi) {
        mydata::hi = hi;
    }

    const QString &getLo() const {
        return lo;
    }

    void setLo(const QString &lo) {
        mydata::lo = lo;
    }

    double getMaxx() const {
        return maxx;
    }

    void setMaxx(double maxx) {
        mydata::maxx = maxx;
    }

    double getMinm() const {
        return minm;
    }

    void setMinm(double minm) {
        mydata::minm = minm;
    }

    const QString &getName() const {
        return name;
    }

    void setName(const QString &name) {
        mydata::name = name;
    }

private:
    QString hi;
    QString lo;
    double maxx;
    double minm;
    QString name;
};

#endif // MYDATA_H
