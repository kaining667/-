#ifndef FAMALEPAGE_H
#define FAMALEPAGE_H

#include <QPushButton>
#include <QWidget>
#include <QMessageBox>

#include "war.h"


namespace Ui {
class famalePage;
}

class famalePage : public QWidget
{
    Q_OBJECT

public:
    explicit famalePage(QWidget *parent = nullptr);
    ~famalePage();
    War *warpage = nullptr;

signals:
    void back();

private slots:
    void on_pushButton_2_clicked();

private:
    Ui::famalePage *ui;
};

#endif // FAMALEPAGE_H
