#ifndef GLOBAL_H
#define GLOBAL_H

#include "waritem.h"
#include "myuser.h"

extern warItem myitem;//生病模块全局函数

extern myUser myuser;//用户全局函数


#endif // GLOBAL_H
