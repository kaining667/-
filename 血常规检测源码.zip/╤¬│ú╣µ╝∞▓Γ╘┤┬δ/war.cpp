#include "war.h"
#include "ui_war.h"
#include "myuser.h"
#include <QMessageBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>

War::War(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::War)
{
    ui->setupUi(this);



    QPushButton *button2 = new QPushButton("前往打印");
    QPushButton *button3 = new QPushButton("刷新");

    // 创建水平布局用于放置三个按钮
    QHBoxLayout *horizontalLayout = new QHBoxLayout();
    horizontalLayout->addWidget(button2);
    horizontalLayout->addWidget(button3);

    // 创建垂直布局
    QVBoxLayout *verticalLayout = new QVBoxLayout(this);
    // 这里添加一个可伸展的空白部件，将按钮挤到下方
    verticalLayout->addStretch(1);
    verticalLayout->addLayout(horizontalLayout);






    // 创建垂直布局
    QVBoxLayout *layout = new QVBoxLayout(this);
    // 将表格添加到布局中
    layout->addWidget(ui->tableWidget);
    // 设置布局到窗口
    this->setLayout(layout);

    //设置button32为刷新，加载数据
    connect(button3, &QPushButton::clicked, this, [this](bool) {
        QMessageBox msgBox;
        int size = myitem.getMyWar().size();
        if(size){
            msgBox.setText("刷新成功");
            msgBox.setWindowTitle("成功");
        }else{
            msgBox.setText("未检测出异常");
            msgBox.setWindowTitle("提示界面");
        }
        setupTable(size);
        msgBox.exec();
        qDebug()<<size;
    });

    //写button2的表达式，为打印
    connect(button2, &QPushButton::clicked, this, [this](bool) {
        QMessageBox msgBox;
        QString name = myuser.getName();
        QString age = myuser.getAge();
        QString tel = myuser.getTel();
        QString sex = myuser.getSex();
        QString contest = "患者姓名 ： " + name + "   患者年龄 ： " + age + "   患者电话 ：" + tel + "   患者性别 ： " + sex;
        qDebug()<<contest<<" ";
        msgBox.setText(contest);
        msgBox.setWindowTitle("打印窗口");
        QPushButton *printButton = msgBox.addButton("打印", QMessageBox::ActionRole);
        msgBox.exec();
    });
}

War::~War()
{
    delete ui;
}

void War::setupTable(int n) {

    ui->tableWidget->setRowCount(n);
    ui->tableWidget->setColumnCount(4);

    std::vector<std::vector<std::string>> item;

    //获取数据库中的数据
    QMap<int,mydata> data ;
    if(myuser.getSex()=="女")data = queryAllDataFromTable("femalewar");
    else data = queryAllDataFromTable("malewar");

    //获取本人的数据
    std::vector<std::pair<int,double>> Item = myitem.getMyWar();

    for(auto [val1,val2]:Item){
        if(data.find(val1)!=data.end()){
            std::vector<std::string> temp;
            temp.push_back(data[val1].getName().toStdString());
            temp.push_back(std::to_string(data[val1].getMaxx())+"~"+std::to_string(data[val1].getMinm()));
            if(data[val1].getMaxx()<val2){
                //参考值，状态，建议
                temp.push_back("偏大");
                temp.push_back(data[val1].getHi().toStdString());
                item.push_back(temp);
            }else{
                temp.push_back("偏小");
                temp.push_back(data[val1].getLo().toStdString());
                item.push_back(temp);
            }
        }
    }

    for(int row = 0; row < n; ++row){
        QString it1 = QString::fromStdString(item[row][0]);
        QString it2 = QString::fromStdString(item[row][1]);
        QString it3 = QString::fromStdString(item[row][2]);
        QString it4 = QString::fromStdString(item[row][3]);
        QTableWidgetItem *item1 = new QTableWidgetItem(it1);
        QTableWidgetItem *item2 = new QTableWidgetItem(it2);
        QTableWidgetItem *item3 = new QTableWidgetItem(it3);
        QTableWidgetItem *item4 = new QTableWidgetItem(it4);
        ui->tableWidget->setItem(row, 0, item1);
        ui->tableWidget->setItem(row, 1, item2);
        ui->tableWidget->setItem(row, 2, item3);
        ui->tableWidget->setItem(row, 3, item4);
    }

}

void War::on_gtprint_clicked()
{
    QMessageBox msgBox;
    QString name = myuser.getName();
    QString age = myuser.getAge();
    QString tel = myuser.getTel();
    QString sex = myuser.getSex();
    QString contest = "患者姓名 ： " + name + "   患者年龄 ： " + age + "   患者电话 ：" + tel + "   患者性别 ： " + sex;
    qDebug()<<contest<<" ";
    msgBox.setText(contest);
    msgBox.setWindowTitle("打印窗口");
    QPushButton *printButton = msgBox.addButton("打印", QMessageBox::ActionRole);
    msgBox.exec();
}



QMap<int,mydata> War::queryAllDataFromTable(const QString& tableName) {
    QMap<int,mydata> result;

    // 建立数据库连接
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("127.0.0.1");  //连接本地主机
    db.setPort(3306);
    db.setDatabaseName("war");  //Mysql 创建的数据库名称
    db.setUserName("root");
    db.setPassword("123456");    //安装 Mysql 设置的密码
    bool ok = db.open();
    if (ok){
        qDebug() << "link success";
    }
    else {
        qDebug() <<  "link failed";
    }
    // 执行查询语句
    // 假设表名为'table_name'，要查询的列名为'column_name'
    QString columnName = "column_name";

    QSqlQuery query(db);
    query.prepare(QString("SELECT * FROM %1").arg(tableName));
    if (query.exec()) {
        while (query.next()) {
            // 获取指定列的值
            QVariant value = query.value(columnName);
            mydata myData;
            myData.setHi(query.value("high").toString());
            myData.setLo(query.value("low").toString());
            myData.setMaxx(query.value("maxx").toDouble());
            myData.setMinm(query.value("minn").toDouble());
            myData.setName(query.value("name").toString());
            result[query.value("id").toInt()]=myData;
        }
    } else {
        qDebug() << "查询失败: " << query.lastError().text();
    }


    db.close();

    return result;
}
