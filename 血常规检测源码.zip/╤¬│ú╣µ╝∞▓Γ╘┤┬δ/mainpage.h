#ifndef MAINPAGE_H
#define MAINPAGE_H

#include <QWidget>

#include "myuser.h"
#include "malepage.h"
#include "famalepage.h"
#include "global.h"
#include "dectct.h"

//---------------------------------------------------------

//---------------------------------------------------------

QT_BEGIN_NAMESPACE
namespace Ui {

class MainPage;
}
QT_END_NAMESPACE

class MainPage : public QWidget
{
    Q_OBJECT

public:
    MainPage(QWidget *parent = nullptr);
    ~MainPage();
    malePage *malepage = nullptr;
    famalePage *famalepage = nullptr;
    dectct *dectet = nullptr;

    //---------------------------------------------------------


    //---------------------------------------------------------

    QMap<QString, QWidget*> pageMap;

private slots:
    void on_pushButton_clicked();

private:
    Ui::MainPage *ui;
};
#endif // MAINPAGE_H
