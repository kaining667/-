#include "mainpage.h"
#include "./ui_mainpage.h"
#include <QMessageBox>
#include <QDebug>
#include <QVBoxLayout>

myUser myuser;//实例化对象myuser

warItem myitem;//实例化对象myitem


MainPage::MainPage(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::MainPage)
{
    ui->setupUi(this);

    //---------------------------------------------------------
    // 创建垂直布局
    QVBoxLayout *layout = new QVBoxLayout(this);
    // 将ui添加到布局中
    layout->addWidget(ui->widget);
    // 设置布局到窗口
    this->setLayout(layout);
    //---------------------------------------------------------

    this -> malepage = new malePage;
    this -> famalepage = new famalePage;

    this -> dectet = new dectct;

    malepage->setWindowTitle("男性血常规检测");
    famalepage->setWindowTitle("女性血常规检测");

    dectet->setWindowTitle("血常规检测");

    pageMap["男"] = malepage;
    pageMap["女"] = famalepage;


    connect(ui->Login, &QPushButton::clicked, this, [this](bool) {
        QString userSex = ui -> userSexEdit -> text();
        QString userName = ui -> userNameEdit -> text();
        QString userTel = ui -> userTelEdit -> text();
        QString userAge = ui -> userAgeEdit -> text();

        myuser.setAge(userAge);
        myuser.setName(userName);
        myuser.setSex(userSex);
        myuser.setTel(userTel);

        if (pageMap.contains(userSex)) {
            dectet -> show();
        } else {
            QMessageBox::warning(this, "提示", "请输入正确性别");
        }
    });


    connect(this -> malepage,&malePage::back,[=](){
        this -> malepage -> hide();
        this -> show();
    });

    connect(this -> famalepage,&famalePage::back,[=](){
        this -> famalepage -> hide();
        this -> show();
    });

    connect(this -> dectet,&dectct::back,[=](){
        this -> dectet -> hide();
        this -> show();
    });

}

MainPage::~MainPage()
{
    delete ui;
}


void MainPage::on_pushButton_clicked()
{

}


